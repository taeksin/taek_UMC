import React from 'react'
import * as S from './Movie.style';

const IMG_BASE_URL="https://image.tmdb.org/t/p/w500";

  function Movie(props){
    return(
      <S.MovieContainer>
        <img src={`${IMG_BASE_URL}${props.movieData.poster_path}`} alt={props.movieData.title} />
        <S.MovieDetail>
          {props.movieData.title}
          <br></br>
          <br></br>
          {props.movieData.vote_average}
          </S.MovieDetail>
        <S.MovieInfo>
          {props.movieData.title}
          {props.movieData.overview}
        </S.MovieInfo>
      </S.MovieContainer>
    )
  }

export default Movie;